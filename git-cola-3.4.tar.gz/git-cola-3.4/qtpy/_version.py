version_info = (1, 7, 1)
__version__ = '.'.join(map(str, version_info))
