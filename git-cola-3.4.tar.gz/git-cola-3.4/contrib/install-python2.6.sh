#!/bin/sh
./contrib/travis-build --sudo --verbose contrib/install-python2.6.yaml "$@"
