Thanks
======
`git-cola` was made possible thanks to the contributions of the following people:

* Aaron Cook
* Aaron Wolf
* Adam Lesperance
* Adrien be
* AJ Bagwell
* Alex Chernetz
* Alex Gulyás
* Alexander Kozienko
* Alf Eaton
* anderben
* Andreas Schnederle-Wagner
* Andreas Sommer
* Andrej Kvasnica
* Andrew Chen
* Andrew Hemming
* Arthur Coelho
* Audrius Karabanovas
* balping
* Barış ÇELİK
* Barry Roberts
* Boris W
* Ben Boeckel
* Ben Cole
* Benedict Lee
* Benoît Nouyrigat
* Bert Jacobs
* Birger Skogeng Pedersen
* 林博仁 (Buo-ren Lin)
* cclaus
* Charles 101
* Christian Jann
* Christopher Meng
* Clément Pit--Claudel
* Constantine Grantcharov
* Daniel Fahlke
* Daniel Jay Haskin
* Daniel Harding
* Daniel King
* Dave Thomas
* David Aguilar
* David Fernandez
* David LeGare
* David Martínez Martí
* Dawid Drozd
* Dennis Gilmore
* deniz1a
* Dmitry Kann
* Dmitry Pashkevich
* Doug Hoskisson
* Drugoy
* Efimov Vasily
* Eric Drechsel
* Erop @EgZvor
* Erwan Bousse
* Fabio Coatti
* Filip Danilović
* fu7mu4
* Garoe Dorta
* Geoffrey van Wyk
* geotavros
* `Git Hackers <http://git-scm.com/about>`_
* green-eyed-bear
* Glen Mailer
* Guillaume de Bure
* Guo Yunhe
* Harro Verton
* Hannes @kannes
* Igor Galarraga
* Igor Kopach
* Ilya Tumaykin
* Ingo Weinhold
* Ismael Juma
* Iulian Udrea
* Ivar Smolin
* Jan @hanksoff
* Jan Šilhan
* Jan Tumanov
* jakubklos77
* Jakub Szymański
* Jakub Wilk
* James Geiger
* Javier Rodriguez Cuevas
* Jeff Dagenais
* Jérôme Carretero
* jfessard
* JiCiT
* Jimmy M. Coleman
* Joachim Lusiardi
* Johannes Löhnert
* Johann Schmitz
* Jordan Bedwell
* Josh Noe
* Josh Taylor
* Justin Lecher
* Kai Krakow
* Karl Bielefeldt
* Karthik Manamcheri
* Kelvie Wong
* Kerrick Staley
* Kevin Kofler
* Kirit Sælensminde
* Kyle Slane
* László Böszörményi
* Leho Kraav
* Lev Zlotin
* Louis Rousseau
* Libor Jelinek
* Liviu Cristian Mirea-Ghiban
* Luca Ottaviano
* Łukasz Wojniłowicz
* Luke Bakken
* Maarten Nieber
* Maaaks
* Maciej Filipiak
* Mahmoud Hossam
* Mateusz Kedzior
* Maicon D. Filippsen
* Marcin Mielniczuk
* Marco Costalba
* Mariusz Jaskółka
* Markus Heidelberg
* Martin Konecny
* Matěj Šmíd
* Matthew Levine
* Matthias Mailänder
* Micha Rosenbaum
* Michael Geddes
* Michael Homer
* Mickael Albertus
* Mike Hanson
* MikHulk
* Mikołaj Milej
* Minarto Margoliono
* Mosaab Alzoubi
* Muhammad Bashir Al-Noimi
* Myz
* Naraesk
* Niel Buys
* Nick Todd
* Nicolas Dietrich
* Nikos Roussos
* Noel Grandin
* NotSqrt
* ochristi
* Oliver Haessler
* OmegaPhil (Omega Weapon)
* Owen Healy
* Pamela Strucker
* Paolo G. Giarrusso
* Parashurama Rhagdamaziel
* Patrick Browne
* Paul Hildebrandt
* Paul Weingardt
* Paulo Fidalgo
* Pavel Borecki
* Pavel Rehak
* Peter Dave Hello
* Peter Júnoš
* Petr Gladkikh
* Philip Stark
* Pilar Molina Lopez
* Radek Novacek
* Radek Postołowicz
* Rafael Nascimento
* Rafael Reuber
* Raghavendra Karunanidhi
* Rainer Müller
* Robbert Korving
* Robert Pollak
* Rolando Espinoza La fuente
* Rustam Safin
* Samsul Ma'arif
* Sebastian Brass
* Sergey Leschina
* Srinivasa Nallapati
* Stan Angeloff
* Stanisław Halik
* Stefan Naewe
* Steffen Prohaska
* Stephen Groat
* Sven Claussner
* Szymon Judasz
* Taylor Braun-Jones
* Thiemo van Engelen
* Thomas Kiley
* Thomas Kluyver
* Thomas Thorne
* Tim Schumacher
* Trevor Alexander
* Ugo Riboni
* Uri Okrent
* Utku Karatas
* Ｖ字龍 (Vdragon)
* Vaibhav Sagar
* Vaiz
* Ved Vyas
* Victorhck
* Ville Skyttä
* Virgil Dupras
* Vitor Lobo
* v.paritskiy
* Wolfgang Ocker
* wsdfhjxc
* Xie Hua Liang (xieofxie)
* Yi EungJun
* Zauber Paracelsus
* Zeioth
* Zhang Han
* 0xflotus
